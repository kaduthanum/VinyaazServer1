<?php

class Application_Model_DbTable_Product1 extends Zend_Db_Table_Abstract
{

    protected $_name = 'product';


}

