<?php

class Application_Model_DbTable_Productproperty extends Zend_Db_Table_Abstract
{

    protected $_name = 'product_property';


}

