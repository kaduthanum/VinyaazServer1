<?php

class Application_Model_DbTable_Productppropertymedia extends Zend_Db_Table_Abstract
{

    protected $_name = 'product_property_media';


}

